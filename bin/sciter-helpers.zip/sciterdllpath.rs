use std::env;
use std::io;
use std::path::PathBuf;

pub fn scitter_dll_path() -> io::Result<PathBuf> {
    let mut dir = env::current_exe()?;
    dir.pop();
    dir.push("sciter.dll");
    Ok(dir)
}

// / fn main() {
// /     let path = scitter_dll_path().expect("Couldn't");
// /     println!("{}", path.display());
// / }